package model.vo;

public class LiderCiudad {

    private String nombreLider;

    public LiderCiudad() {
    }

    public LiderCiudad(String nombreLider) {
        this.nombreLider = nombreLider;
    }

    public String getNombreLider() {
        return nombreLider;
    }

    public void setNombreLider(String nombreLider) {
        this.nombreLider = nombreLider;
    }

}
